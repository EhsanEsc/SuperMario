
make
./a.out "assets/maps/1/1.txt"
read -p "Press....,,,,"
