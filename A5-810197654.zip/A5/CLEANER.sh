
make clean
read -p "..."
